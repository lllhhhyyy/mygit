package wc_lhy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

import javax.sound.sampled.Line;
import javax.swing.RowFilter;

import org.omg.CORBA.PUBLIC_MEMBER;

public class Count  {

	public int getCountWords() {
		return countWords;
	}

	public void setCountWords(int countWords) {
		this.countWords = countWords;
	}

	public int getCountNull() {
		return countNull;
	}

	public void setCountNull(int countNull) {
		this.countNull = countNull;
	}

	public int getCommetLine() {
		return commetLine;
	}

	public void setCommetLine(int commetLine) {
		this.commetLine = commetLine;
	}

	public int getCountChar() {
		return countChar;
	}

	public void setCountChar(int countChar) {
		this.countChar = countChar;
	}

	public int getCountLine() {
		return countLine;
	}

	public void setCountLine(int countLine) {
		this.countLine = countLine;
	}

	public int getCodeLine() {
		return codeLine;
	}

	public void setCodeLine(int codeLine) {
		this.codeLine = codeLine;
	}

	int countWords;//���ʸ���
	int countNull;//�հ���
	int commetLine;//ע����
	int countChar;//�ַ�����
	int countLine;//������
	int codeLine;//������
	
	public Count() {
		// TODO Auto-generated constructor stub
		this.countChar = 0;
		this.countLine = 0;
		this.commetLine = 0;
		this.countWords = 0;
		this.codeLine = 0;
		this.countNull = 0;
	}
	
	/*�������ܣ��ַ����������ʸ���������*/	
	public   void  countLine(String path) throws IOException {
		InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(path));
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		while (bufferedReader.read()!=-1) {
			String string = bufferedReader.readLine();
			countLine++;//����
		}
		bufferedReader.close();
		System.out.println("������ "+getCountLine());
	}
	
	public   void  countChar(String path) throws IOException {
		InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(path));
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		while (bufferedReader.read()!=-1) {
			String string = bufferedReader.readLine();
			if(string != null){
			countChar = countChar + string.length();//�ַ�����
			}
		}
		bufferedReader.close();
		System.out.println("�ַ����� "+getCountChar());
	}
	
	public   void  countWords(String path) throws IOException {
		InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(path));
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		while (bufferedReader.read()!=-1) {
			String string = bufferedReader.readLine();
			
			if(string != null){
			countWords = countWords + string.split("\\s").length;//�ʵĸ���
			}
			
		}
		bufferedReader.close();
		System.out.println("������:" + getCountWords());
	}
	
	//��������У�ע���С��հ���
	@SuppressWarnings("resource")
	public void countComplex(String filePath) throws IOException {
		InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(filePath));
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		//ע����ƥ��
		Pattern commetPattern = Pattern.compile("(^//.*$)|(^/\\*.*\\*/$)|(^/\\*\\*.*$)|(^\\*.*$)|.*\\*/$", 
				Pattern.MULTILINE + Pattern.DOTALL);
		//�հ���ƥ��
		Pattern nullPattern = Pattern.compile("^\\s*$");
		//������ƥ��
		Pattern codePattern = Pattern.compile("\\s*",
				Pattern.MULTILINE + Pattern.DOTALL);
		//System.out.println(9);
		String row;
		while ((row = bufferedReader.readLine())!= null) {
			if(nullPattern.matcher(row).find()){
				countNull++;
			}
			//ע��
			 if ((row!=null)&&commetPattern.matcher(row).matches()) {
				commetLine++;
			}
			//������
			 if((row!=null)&&codePattern.matcher(row).find()) {
			//else {
				codeLine++;
			}
		}
		codeLine = codeLine - commetLine-countNull;
	}	
}
